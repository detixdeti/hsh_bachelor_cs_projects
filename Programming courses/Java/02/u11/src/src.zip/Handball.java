/**
 * Gruppe 03
 * @author Schehat
 * U11
 */
public class Handball extends Ballspiel {
    
    /**
     * return Spieldauer
     */
    @Override public int getSpieldauer() {
        return 60;
    }
    
    /**
     * 
     * @return Mannschafsgr��e
     */
    public int mannschaftsGroesse() {
        return 7;
    }
}
