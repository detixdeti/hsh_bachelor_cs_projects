/**
 * Gruppe 03
 * @author Schehat
 * U11
 */
public class Ballspiel {
    
    /**
     * 
     * @return Mannschaften
     */
    public int getMannschaften() {
        return 2;
    }
    
    /**
     * 
     * @return Spieldauer
     */
    public int getSpieldauer() {
        return -1;
    }
    
    /**
     * 
     * @return B�lle
     */
    public int getBaelle() {
        return 1;
    }
}
