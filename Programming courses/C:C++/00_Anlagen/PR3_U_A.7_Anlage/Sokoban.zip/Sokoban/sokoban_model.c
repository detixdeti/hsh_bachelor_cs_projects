#include "sokoban_model.h"

static struct sokoban_field sokoban_field[SOKOBAN_FIELD_HEIGHT][SOKOBAN_FIELD_WIDTH];
static int sokoban_mover_row = 0;
static int sokoban_mover_column = 0;

void sokoban_init_field(int level)
{
  /* Hier muss das Array sokoban_field gefüllt werden.
   * Die notwendigen Daten befinden sich in sokoban_level[level]...
   * Außerdem müssen hier die Variablen sokoban_mover_row und
   * sokoban_mover_column gesetzt werden.
   */
}

enum sokoban_field_type sokoban_get_field(int row, int column)
{
  return sokoban_field[row][column].type;
}

enum sokoban_object_type sokoban_get_object(int row, int column)
{
  return sokoban_field[row][column].object;
}

void sokoban_move_north(void)
{
  /* Hier muss das Array sokoban_field aktualisiert werden. */
}

void sokoban_move_east(void)
{
  /* Hier muss das Array sokoban_field aktualisiert werden. */
}

void sokoban_move_south(void)
{
  /* Hier muss das Array sokoban_field aktualisiert werden. */
}

void sokoban_move_west(void)
{
  /* Hier muss das Array sokoban_field aktualisiert werden. */
}

