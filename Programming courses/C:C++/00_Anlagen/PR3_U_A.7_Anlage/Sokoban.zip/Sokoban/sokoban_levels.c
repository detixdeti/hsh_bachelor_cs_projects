#include "sokoban_levels.h"

/*
 * Verschiedene Level
 * Bedeutung der Zeichen:
 *   M - Spielfigur
 *   B - Kiste
 *   S - Zielfeld
 *   . - begehbares Feld
 *   # - Mauer
 * Alle anderen Felder sind leer.
 */
char sokoban_level[SOKOBAN_LEVELS][SOKOBAN_FIELD_HEIGHT][SOKOBAN_FIELD_WIDTH] = {
/* Splash Screen */ {
"###################",
"#M................#",
"#.BBB.BBB.B.B.BBB.#",
"#.B...B.B.B.B.B.B.#",
"#.BBB.B.B.BB..B.B.#",
"#...B.B.B.B.B.B.B.#",
"#.BBB.BBB.B.B.BBB.#",
"#.................#",
"#..BBB.BBB.B...B..#",
"#..B.B.B.B.BB..B..#",
"#..BB..BBB.B.B.B..#",
"#..B.B.B.B.B..BB..#",
"#..BBB.B.B.B...B..#",
"#.................#",
"#.................#",
"###################"
},
/* Level 1 */ {
"                   ",
"                   ",
"    #####          ",
"    #...#          ",
"    #B..#          ",
"  ###..B##         ",
"  #..B.B.#         ",
"###.#.##.#   ######",
"#...#.##.#####..SS#",
"#.B..B..........SS#",
"#####.###.#M##..SS#",
"    #.....#########",
"    #######        ",
"                   ",
"                   ",
"                   "
}
};


