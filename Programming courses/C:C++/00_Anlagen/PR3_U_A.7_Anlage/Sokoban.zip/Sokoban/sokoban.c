#include <stdbool.h>
#include <stdio.h>

#include <SDL.h>

#include "sokoban_images.h"
#include "sokoban_model.h"

/* Screen dimension constants */
const int SCREEN_WIDTH = SOKOBAN_FIELD_WIDTH * SOKOBAN_IMAGE_WIDTH;
const int SCREEN_HEIGHT = SOKOBAN_FIELD_HEIGHT * SOKOBAN_IMAGE_HEIGHT;

SDL_Rect sokoban_rect(int row, int column)
{
  SDL_Rect rect;
  rect.x = column * SOKOBAN_IMAGE_WIDTH;
  rect.y = row * SOKOBAN_IMAGE_HEIGHT;
  rect.w = SOKOBAN_IMAGE_WIDTH;
  rect.h = SOKOBAN_IMAGE_HEIGHT;
  return rect;
}

void sokoban_fill(SDL_Surface* s)
{
  int row;
  int column;
  for (row = 0; row < SOKOBAN_FIELD_HEIGHT; ++row)
  {
    for (column = 0; column < SOKOBAN_FIELD_WIDTH; ++column)
    {
      enum sokoban_field_type field = sokoban_get_field(row, column);
      enum sokoban_object_type object = sokoban_get_object(row, column);
      SDL_Surface* i = sokoban_get_image(field, object);
      if (i)
      {
        SDL_Rect rect = sokoban_rect(row, column);
        SDL_BlitSurface( i, NULL, s, &rect );
      }
    }
  }
}


int main( int argc, char* args[] )
{
  int running = true;
  SDL_Event e;
  SDL_Window* window = NULL;
  SDL_Surface* screenSurface = NULL;

  if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
  {
    printf( "Initialisierung der SDL fehlgeschlagen! SDL_Error: %s\n", SDL_GetError() );
  }
  else
  {
    window = SDL_CreateWindow( "Sokoban", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
    if( window == NULL )
    {
      printf( "Fenster konnte nicht erzeugt werden! SDL_Error: %s\n", SDL_GetError() );
    }
    else
    {
      screenSurface = SDL_GetWindowSurface( window );

      sokoban_load_images();
      sokoban_init_field(0);
      SDL_FillRect( screenSurface, NULL, SDL_MapRGB( screenSurface->format, 0x00, 0x00, 0x00 ) );
      sokoban_fill(screenSurface);
      SDL_UpdateWindowSurface( window );
      SDL_Delay(5000);
      sokoban_init_field(1);

      while( running )
      {
        while( SDL_PollEvent( &e ) != 0 )
        {
          if( e.type == SDL_QUIT )
          {
            printf("Auf Wiedersehen!\n");
            running = false;
          }
          else if( e.type == SDL_KEYDOWN )
          {
            switch( e.key.keysym.sym )
            {
            case SDLK_UP:
              sokoban_move_north();
              break;
            case SDLK_DOWN:
              sokoban_move_south();
              break;
            case SDLK_LEFT:
              sokoban_move_west();
              break;
            case SDLK_RIGHT:
              sokoban_move_east();
              break;
            default:
              break;
            }
          }
        }
        SDL_FillRect( screenSurface, NULL, SDL_MapRGB( screenSurface->format, 0x00, 0x00, 0x00 ) );
        sokoban_fill(screenSurface);
        SDL_UpdateWindowSurface( window );
      }
      sokoban_free_images();
    }
  }

  SDL_DestroyWindow( window );
  SDL_Quit();

  return 0;
}
