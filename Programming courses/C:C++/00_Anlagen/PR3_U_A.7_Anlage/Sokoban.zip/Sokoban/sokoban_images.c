#include "sokoban_images.h"

#include <SDL.h>

char* sokoban_image_file_name[SOKOBAN_IMAGES] = {
  "mauer.bmp",
  "feld.bmp",
  "kist.bmp",
  "mnchn.bmp",
  "mncho.bmp",
  "mnchs.bmp",
  "mnchw.bmp",
  "feldgr.bmp",
  "kistgr.bmp",
  "mnchngr.bmp",
  "mnchogr.bmp",
  "mnchsgr.bmp",
  "mnchwgr.bmp"
};

SDL_Surface* sokoban_image[SOKOBAN_IMAGES] = { 0 };

void sokoban_load_images(void)
{
  int i;
  for (i = 0; i < SOKOBAN_IMAGES; ++i)
  {
    sokoban_image[i] = SDL_LoadBMP( sokoban_image_file_name[i] );
    if( sokoban_image[i] == NULL )
    {
      printf( "Kann Bild %s nicht laden! SDL Error: %s\n", sokoban_image_file_name[i], SDL_GetError() );
    }
  }
}

SDL_Surface* sokoban_get_image(enum sokoban_field_type field, enum sokoban_object_type object)
{
  if (field == SOKOBAN_FIELD_EMPTY)
  {
    return NULL;
  }
  else if (field == SOKOBAN_FIELD_WALL)
  {
    return sokoban_image[0];
  }
  else if (field == SOKOBAN_FIELD_GROUND)
  {
    if (object == SOKOBAN_OBJECT_NONE)
      return sokoban_image[1];
    else if (object == SOKOBAN_OBJECT_BOX)
      return sokoban_image[2];
    else if (object == SOKOBAN_OBJECT_MOVER_NORTH)
      return sokoban_image[3];
    else if (object == SOKOBAN_OBJECT_MOVER_EAST)
      return sokoban_image[4];
    else if (object == SOKOBAN_OBJECT_MOVER_SOUTH)
      return sokoban_image[5];
    else if (object == SOKOBAN_OBJECT_MOVER_WEST)
      return sokoban_image[6];
  }
  else if (field == SOKOBAN_FIELD_STORAGE)
  {
    if (object == SOKOBAN_OBJECT_NONE)
      return sokoban_image[7];
    else if (object == SOKOBAN_OBJECT_BOX)
      return sokoban_image[8];
    else if (object == SOKOBAN_OBJECT_MOVER_NORTH)
      return sokoban_image[9];
    else if (object == SOKOBAN_OBJECT_MOVER_EAST)
      return sokoban_image[10];
    else if (object == SOKOBAN_OBJECT_MOVER_SOUTH)
      return sokoban_image[11];
    else if (object == SOKOBAN_OBJECT_MOVER_WEST)
      return sokoban_image[12];
  }
  return NULL;
}

void sokoban_free_images(void)
{
  int i;
  for (i = 0; i < SOKOBAN_IMAGES; ++i)
  {
    SDL_FreeSurface(sokoban_image[i]);
    sokoban_image[i] = NULL;
  }
}
