#ifndef SOKOBAN_MODEL_H_
#define SOKOBAN_MODEL_H_

#include "sokoban_levels.h"

enum sokoban_field_type
{
  /* nicht begehbares Feld */
  SOKOBAN_FIELD_EMPTY,
  /* Mauer, ebenfalls nicht begehbar */
  SOKOBAN_FIELD_WALL,
  /* begehbares Feld */
  SOKOBAN_FIELD_GROUND,
  /* Zielfeld, ebenfalls begehbar */
  SOKOBAN_FIELD_STORAGE
};

enum sokoban_object_type
{
  /* kein Objekt vorhanden */
  SOKOBAN_OBJECT_NONE,
  /* Spielfigur, schaut nach Norden */
  SOKOBAN_OBJECT_MOVER_NORTH,
  /* Spielfigur, schaut nach Osten */
  SOKOBAN_OBJECT_MOVER_EAST,
  /* Spielfigur, schaut nach Süden */
  SOKOBAN_OBJECT_MOVER_SOUTH,
  /* Spielfigur, schaut nach Westen */
  SOKOBAN_OBJECT_MOVER_WEST,
  /* Kiste */
  SOKOBAN_OBJECT_BOX
};

struct sokoban_field
{
  enum sokoban_field_type type;
  enum sokoban_object_type object;
};

extern void sokoban_init_field(int level);
extern enum sokoban_field_type sokoban_get_field(int row, int column);
extern enum sokoban_object_type sokoban_get_object(int row, int column);

extern void sokoban_move_north(void);
extern void sokoban_move_east(void);
extern void sokoban_move_south(void);
extern void sokoban_move_west(void);

#endif /* SOKOBAN_MODEL_H_ */
