#ifndef SOKOBAN_IMAGES_H_
#define SOKOBAN_IMAGES_H_

#include <SDL.h>

#include "sokoban_model.h"

#define SOKOBAN_IMAGE_WIDTH 25
#define SOKOBAN_IMAGE_HEIGHT 25
#define SOKOBAN_IMAGES 13

extern void sokoban_load_images(void);
extern SDL_Surface* sokoban_get_image(enum sokoban_field_type field, enum sokoban_object_type object);
extern void sokoban_free_images(void);

#endif /* SOKOBAN_IMAGES_H_ */
