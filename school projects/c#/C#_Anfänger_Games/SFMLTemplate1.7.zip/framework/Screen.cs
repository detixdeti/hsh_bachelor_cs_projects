﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Window;
using SFML.Audio;
using SFML.Graphics;
using SFML.System;
using $safeprojectname$.entities;
using $safeprojectname$.framework;
using $safeprojectname$.utility;

namespace $safeprojectname$.framework
{
    abstract class Screen
    {
        /// <summary>
        /// Die Spielinstanz
        /// </summary>
        public Game game;

        /// <summary>
        /// Setze die Referenz zur Spielinstanz
        /// </summary>
        /// <param name="_game">Die Spielinstanz</param>
        public void SetGame(Game _game)
        {

            game = _game;
        }

        /// <summary>
        /// Wird immer einmal ausgeführt, wenn dieser Screen aufgerufen wird (auch beim zurückwechseln)
        /// </summary>
        public abstract void Setup();

        /// <summary>
        /// Wird jeden Frame ausgeführt. Stellt einen Schritt in der Spiellogik da.
        /// </summary>
        /// <param name="deltatime">Die Zeit dieses Frames in Sekunden</param>
        public abstract void Loop(float deltatime);

        /// <summary>
        /// Zeichnet den Screen in das aktuelle Spielfenster
        /// </summary>
        public abstract void Render();

        /// <summary>
        /// Zeichne des übergebene Spielobjekt
        /// </summary>
        /// <param name="obj">Ein zeichenbares Spielobjekt (Shape, Sprite,...)</param>
        public void Draw(Drawable obj)
        {
            game.gameWindow.Draw(obj);

        }

    }
}
