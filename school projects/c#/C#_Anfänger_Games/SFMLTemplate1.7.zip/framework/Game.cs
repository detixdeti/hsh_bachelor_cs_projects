﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Window;
using SFML.Audio;
using SFML.Graphics;
using SFML.System;
using $safeprojectname$.entities;
using $safeprojectname$.framework;
using $safeprojectname$.utility;
using $safeprojectname$.screens;

namespace $safeprojectname$.framework
{
    class Game
    {
        /// <summary>
        /// Referenz auf das Spielfenster
        /// </summary>
        public RenderWindow gameWindow;
   
        /// <summary>
        /// Der aktuell aktive Screen
        /// </summary>
        public Screen activeScreen;

        // Konstanten zur Konfiguration des Spielfensters
        public const uint SCREEN_WIDTH = 800;
        public const uint SCREEN_HEIGHT = 600;
        public const String WINDOW_TITLE = "SFML Game";
        public const int MAX_FPS = 60;

        /// <summary>
        /// Startet eine Spielinstanz
        /// </summary>
        public void StartGame()
        {
            gameWindow = new RenderWindow(new VideoMode(SCREEN_WIDTH, SCREEN_HEIGHT), WINDOW_TITLE, Styles.Close);
            
            gameWindow.Closed += new EventHandler(OnClose);

            gameWindow.SetFramerateLimit(MAX_FPS);

            gameWindow.SetKeyRepeatEnabled(false);

            activeScreen = new MainScreen();

            activeScreen.SetGame(this);

            activeScreen.Setup();

            while (gameWindow.IsOpen)
            {
                gameWindow.DispatchEvents();

                gameWindow.Clear();

                activeScreen.Loop(1.0f / MAX_FPS);

                activeScreen.Render();

                gameWindow.Display();
            }

        }

        /// <summary>
        /// Wechselt den Screen zu einem anderen Screen
        /// </summary>
        /// <param name="newScreen">Der neue Screen</param>
        public void SwitchScreen(Screen newScreen)
        {
            activeScreen = newScreen;
            newScreen.SetGame(this);
            newScreen.Setup();
        }

        /// <summary>
        /// Wird aufgerufen, wenn der User den Schließen Button drückt.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void OnClose(object sender, EventArgs e)
        {
            gameWindow.Close();
        }
    }
}
