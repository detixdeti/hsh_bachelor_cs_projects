﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Window;
using SFML.Audio;
using SFML.Graphics;
using SFML.System;
using $safeprojectname$.entities;
using $safeprojectname$.framework;
using $safeprojectname$.utility;
using $safeprojectname$.screens;

namespace $safeprojectname$.screens
{
    class MainScreen : Screen
    {
        // Objekte hier deklarieren


       
        /// <summary>
        /// Wird immer einmal ausgeführt, wenn dieser Screen aufgerufen wird (auch beim zurückwechseln)
        /// </summary>
        public override void Setup()
        {

        }

        /// <summary>
        /// Wird jeden Frame ausgeführt. Stellt einen Schritt in der Spiellogik da.
        /// </summary>
        /// <param name="deltatime">Die Zeit dieses Frames in Sekunden</param>
        public override void Loop(float deltatime)
        {

        }

        /// <summary>
        /// Zeichnet den Screen in das aktuelle Spielfenster
        /// </summary>
        public override void Render()
        {

        }
    }
}
