﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Window;
using SFML.Audio;
using SFML.Graphics;
using SFML.System;
using $safeprojectname$.entities;
using $safeprojectname$.framework;
using $safeprojectname$.utility;
using $safeprojectname$.screens;

namespace $safeprojectname$.screens
{
    class ScoreScreen : Screen
    {

        public ScoreScreen(int _score)
        {
            score = _score;
        }
        // Die Schriftart
        Font font;

        // Die Textanzeigen
        Text mainText;
        Text ScoreText;
        Text subText;

        // Die übergebene Punktzahl
        int score;

        public override void Setup()
        {
            font = new Font("assets/arial.ttf");
            mainText = new Text("GameOver", font, 100);
            mainText.Origin = new Vector2f(mainText.GetLocalBounds().Width / 2, mainText.GetLocalBounds().Height / 2);
            mainText.Position = new Vector2f(400, 100);

            ScoreText = new Text("Score: " + score.ToString(), font, 50);
            ScoreText.Origin = new Vector2f(ScoreText.GetLocalBounds().Width / 2, ScoreText.GetLocalBounds().Height / 2);
            ScoreText.Position = new Vector2f(400, 270);

            subText = new Text("Press Enter to restart", font, 20);
            subText.Origin = new Vector2f(subText.GetLocalBounds().Width / 2, subText.GetLocalBounds().Height / 2);
            subText.Position = new Vector2f(400, 400);

        }

        public override void Loop(float deltatime)
        {

            if (Keyboard.IsKeyPressed(Keyboard.Key.Return))
            {
                game.SwitchScreen(new MainScreen());
            }
        }

        public override void Render()
        {
            Draw(mainText);
            Draw(subText);
            Draw(ScoreText);
        }
    }
}
