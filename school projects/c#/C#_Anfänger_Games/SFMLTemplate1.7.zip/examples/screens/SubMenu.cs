﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Window;
using SFML.Audio;
using SFML.Graphics;
using SFML.System;
using $safeprojectname$.entities;
using $safeprojectname$.framework;
using $safeprojectname$.utility;
using $safeprojectname$.screens;

namespace $safeprojectname$.screens
{
    class SubMenu : SubScreen
    {

        Button resume;
        Button close;

        public SubMenu(Screen parentScreen) : base(parentScreen)
        {

        }

        public override void Setup()
        {
            resume = new Button(this, new Vector2f(300, 200), new Vector2f(200, 50), "Resume", 20);
            close = new Button(this, new Vector2f(300, 300), new Vector2f(200, 50), "Close", 20);
        }

        public override void Loop(float deltatime)
        {
            if (resume.click)
            {
                //Return to parentScreen, close Menu
                goBack();
            }

            if (close.click)
            {
                //Ends program
                game.gameWindow.Close();

            }

            //Loop objects of this submenu
            resume.loop();
            close.loop();


            //Uncomment to update the parentScreen, else parentScreen will be "frozen"
            //parentScreen.loop();
        }

        public override void Render()
        {
            //Render the parentScreen
            parentScreen.Render();

            //Render own Objects ontop of parentScreen
            resume.draw();
            close.draw();
        }


    }
}
